
import React, { useState, useEffect, useRef } from 'react';
import { View, Message, Chat } from './types';
import { Icons } from './constants';
import AdContainer from './components/AdContainer';
import { generateAIResponse } from './services/gemini';
import { GoogleGenAI, LiveServerMessage, Modality, Blob } from '@google/genai';

// --- Utility Functions for Audio ---

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

function createBlob(data: Float32Array): Blob {
  const l = data.length;
  const int16 = new Int16Array(l);
  for (let i = 0; i < l; i++) {
    int16[i] = data[i] * 32768;
  }
  return {
    data: encode(new Uint8Array(int16.buffer)),
    mimeType: 'audio/pcm;rate=16000',
  };
}

// --- Components ---

const TeleStreamLogo: React.FC<{ size?: string; className?: string }> = ({ size = "w-24 h-24", className = "" }) => (
  <div className={`${size} logo-gradient rounded-full flex items-center justify-center soft-shadow neon-glow animate-float ${className}`}>
    <Icons.PaperPlane className="w-2/3 h-2/3" />
  </div>
);

const AuthScreen: React.FC<{ onAuth: () => void }> = ({ onAuth }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [step, setStep] = useState<'form' | 'loading'>('form');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('loading');
    setTimeout(() => {
      onAuth();
    }, 1800);
  };

  if (step === 'loading') {
    return (
      <div className="fixed inset-0 z-50 dark-gradient flex flex-col items-center justify-center p-8 text-center">
        <TeleStreamLogo className="mb-8 scale-125 opacity-20 blur-sm absolute" />
        <div className="w-20 h-20 border-4 border-cyan-400/30 border-t-cyan-400 rounded-full animate-spin mb-6 mx-auto relative z-10"></div>
        <h2 className="text-xl font-bold text-white relative z-10">Establishing Direct-Link...</h2>
        <p className="text-cyan-400/60 text-sm mt-2 relative z-10">Authenticating neural keys worldwide.</p>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 dark-gradient flex flex-col items-center justify-center p-8 transition-all overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none opacity-10">
        <div className="grid grid-cols-10 h-full">
          {[...Array(100)].map((_, i) => <div key={i} className="border-[0.5px] border-white/20"></div>)}
        </div>
      </div>
      
      <div className="text-center mb-12 relative z-10">
        <TeleStreamLogo className="mx-auto mb-6" />
        <h1 className="text-5xl font-extrabold text-white tracking-tight text-glow">TeleStream</h1>
        <p className="text-cyan-400/60 font-bold text-xs uppercase tracking-[0.4em] mt-3">Worldwide Private Network</p>
      </div>

      <div className="w-full max-w-sm glass-morphism p-8 rounded-[3rem] space-y-6 relative z-10 border-white/10">
        <form onSubmit={handleSubmit} className="space-y-4">
          <input 
            type="email" 
            placeholder="Identity Email" 
            required
            className="w-full bg-slate-900/60 p-5 rounded-3xl border border-white/5 focus:outline-none focus:ring-2 focus:ring-cyan-500/50 text-white placeholder-slate-500"
          />
          <input 
            type="password" 
            placeholder="Access Code" 
            required
            className="w-full bg-slate-900/60 p-5 rounded-3xl border border-white/5 focus:outline-none focus:ring-2 focus:ring-cyan-500/50 text-white placeholder-slate-500"
          />
          <button 
            type="submit"
            className="w-full bg-gradient-to-r from-cyan-600 to-indigo-600 text-white font-bold py-5 rounded-3xl shadow-2xl shadow-indigo-500/20 active:scale-95 transition-all hover:brightness-110"
          >
            {isLogin ? 'Establish Link' : 'Register Identity'}
          </button>
        </form>
        <button 
          onClick={() => setIsLogin(!isLogin)}
          className="w-full text-slate-400 text-xs font-bold uppercase tracking-widest hover:text-white transition-colors"
        >
          {isLogin ? 'New Identity? Register' : 'Existing Link? Login'}
        </button>
      </div>

      <div className="fixed bottom-6 w-full px-8 flex justify-center z-10">
        <AdContainer type="banner" className="max-w-md bg-transparent border-none" />
      </div>
    </div>
  );
};

// --- Main App ---

const App: React.FC = () => {
  const [view, setView] = useState<View>(View.LOGIN);
  const [messages, setMessages] = useState<Message[]>([
    { id: '1', sender: 'Nova', text: 'Identity verified. Uploading encrypted assets to the node...', timestamp: '10:30 AM', isMe: false, type: 'text' },
    { id: '2', sender: 'Me', text: 'Received. Initializing 2TB buffer for transmission.', timestamp: '10:31 AM', isMe: true, type: 'text' }
  ]);
  const [inputText, setInputText] = useState('');
  const [aiInputText, setAiInputText] = useState('');
  
  const INITIAL_AI_HISTORY: Message[] = [
    { id: 'ai-1', sender: 'TeleStream AI', text: 'Neural Link: Active. I am your TeleStream assistant. How can I facilitate your creativity?', timestamp: 'Now', isMe: false, type: 'text' }
  ];
  
  const [aiHistory, setAiHistory] = useState<Message[]>(INITIAL_AI_HISTORY);
  const [aiLoading, setAiLoading] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showStickers, setShowStickers] = useState(false);
  
  // Translation & Voice States
  const [showTranslator, setShowTranslator] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const recognitionRef = useRef<any>(null);

  // Live Session States
  const [liveStatus, setLiveStatus] = useState<'idle' | 'connecting' | 'linked'>('idle');
  const [liveTranscriptions, setLiveTranscriptions] = useState<{user: string, ai: string}[]>([]);
  const liveSessionRef = useRef<any>(null);
  const audioContextRef = useRef<{ input: AudioContext; output: AudioContext } | null>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const scrollToBottom = () => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  useEffect(() => { scrollToBottom(); }, [messages, aiHistory, liveTranscriptions]);

  const handleAuth = () => setView(View.DASHBOARD);
  const handleLogout = () => {
    if (confirm('Terminate session and de-authorize neural keys?')) {
      setShowSettings(false);
      setView(View.LOGIN);
    }
  };

  // --- Live Neural Link Logic ---

  const startLiveLink = async () => {
    setLiveStatus('connecting');
    setView(View.LIVE);
    setLiveTranscriptions([]);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContextRef.current = { input: inputAudioContext, output: outputAudioContext };

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      let currentAiText = "";
      let currentUserText = "";

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setLiveStatus('linked');
            const source = inputAudioContext.createMediaStreamSource(stream);
            const scriptProcessor = inputAudioContext.createScriptProcessor(4096, 1, 1);
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const pcmBlob = createBlob(inputData);
              sessionPromise.then(session => session.sendRealtimeInput({ media: pcmBlob }));
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputAudioContext.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            // Handle Transcription
            if (message.serverContent?.outputTranscription) {
              currentAiText += message.serverContent.outputTranscription.text;
            } else if (message.serverContent?.inputTranscription) {
              currentUserText += message.serverContent.inputTranscription.text;
            }

            if (message.serverContent?.turnComplete) {
              setLiveTranscriptions(prev => [...prev, { user: currentUserText, ai: currentAiText }]);
              currentAiText = "";
              currentUserText = "";
            }

            // Handle Audio
            const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64Audio) {
              const outputCtx = outputAudioContext;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputCtx.currentTime);
              const audioBuffer = await decodeAudioData(decode(base64Audio), outputCtx, 24000, 1);
              const sourceNode = outputCtx.createBufferSource();
              sourceNode.buffer = audioBuffer;
              sourceNode.connect(outputCtx.destination);
              sourceNode.addEventListener('ended', () => sourcesRef.current.delete(sourceNode));
              sourceNode.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              sourcesRef.current.add(sourceNode);
            }

            if (message.serverContent?.interrupted) {
              for (const s of sourcesRef.current) {
                try { s.stop(); } catch(e) {}
              }
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }
          },
          onerror: (e) => console.error("Live Error", e),
          onclose: () => {
            setLiveStatus('idle');
            setView(View.AI_CHAT);
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          outputAudioTranscription: {},
          inputAudioTranscription: {},
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } }
          },
          systemInstruction: 'You are the TeleStream Neural AI in a LIVE low-latency voice session. Be fast, high-tech, and helpful. You are communicating via a Direct-Link neural interface.'
        }
      });

      liveSessionRef.current = await sessionPromise;
    } catch (err) {
      console.error(err);
      alert("Neural Link failed. Check permissions.");
      setLiveStatus('idle');
      setView(View.AI_CHAT);
    }
  };

  const endLiveLink = () => {
    if (liveSessionRef.current) {
      liveSessionRef.current.close();
      liveSessionRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.input.close();
      audioContextRef.current.output.close();
    }
    setLiveStatus('idle');
    setView(View.AI_CHAT);
  };

  const handleClearAiHistory = () => {
    if (confirm('Permanently purge neural conversation history? This cannot be undone.')) {
      setAiHistory(INITIAL_AI_HISTORY);
    }
  };

  const handleSendMessage = () => {
    if (!inputText.trim()) return;
    setMessages(prev => [...prev, {
      id: Date.now().toString(),
      sender: 'Me',
      text: inputText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isMe: true,
      type: 'text'
    }]);
    setInputText('');
  };

  const handleSendSticker = (sticker: string) => {
    setMessages(prev => [...prev, {
      id: Date.now().toString(),
      sender: 'Me',
      text: sticker,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isMe: true,
      type: 'sticker'
    }]);
    setShowStickers(false);
  };

  const handleAiSend = async (text: string) => {
    if (!text || aiLoading) return;
    let finalPrompt = text;
    if (selectedLanguage) {
      finalPrompt = `Translate the following text to ${selectedLanguage}. Maintain the tone and context: "${text}"`;
    }
    setAiHistory(prev => [...prev, { id: Date.now().toString(), sender: 'Me', text, timestamp: 'Now', isMe: true, type: 'text' }]);
    setAiLoading(true);
    setAiInputText('');
    const response = await generateAIResponse(finalPrompt);
    setAiHistory(prev => [...prev, { id: (Date.now() + 1).toString(), sender: 'TeleStream AI', text: response, timestamp: 'Now', isMe: false, type: 'text' }]);
    setAiLoading(false);
  };

  const toggleVoiceInput = () => {
    if (isRecording) {
      recognitionRef.current?.stop();
      setIsRecording(false);
      return;
    }
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) return;
    const recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.onstart = () => setIsRecording(true);
    recognition.onend = () => setIsRecording(false);
    recognition.onresult = (event: any) => setAiInputText(event.results[0][0].transcript);
    recognition.start();
    recognitionRef.current = recognition;
  };

  const STICKERS = ["🚀", "🔥", "💎", "⭐", "🌈", "🤖", "🎨", "🎬", "📱", "👾", "✨", "🍕", "🛸", "🌍", "🐱", "🐶", "🦊"];
  const SUGGESTED_PROMPTS = ["Draft a 4K video concept", "Explain Direct-Link protocol", "Generate futuristic UI ideas", "Write a cyberpunk story intro", "Code a neural link API mockup"];
  const LANGUAGES = ["Spanish", "French", "German", "Japanese", "Chinese", "Russian", "Italian", "Portuguese", "Korean", "Arabic"];

  return (
    <div className="w-full h-screen bg-[#020617] text-slate-100 overflow-hidden font-sans">
      {view === View.LOGIN && <AuthScreen onAuth={handleAuth} />}
      
      <main className="h-full flex flex-col">
        {/* Navigation / Header */}
        {(view !== View.LOGIN && view !== View.LIVE) && (
          <header className="px-6 pt-12 pb-6 flex items-center justify-between glass-morphism border-b border-white/5">
            <div className="flex items-center gap-3">
              <TeleStreamLogo size="w-10 h-10" />
              <div>
                <h1 className="text-xl font-bold tracking-tight">TeleStream</h1>
                <div className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full shadow-[0_0_5px_#22d3ee]"></span>
                  <span className="text-[8px] font-bold text-cyan-400/60 uppercase tracking-widest">Global Link established</span>
                </div>
              </div>
            </div>
            <div className="flex gap-3">
              {view === View.AI_CHAT && (
                <>
                  <button onClick={startLiveLink} className="w-10 h-10 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center border border-cyan-400/20 active:scale-95 transition-all"><Icons.Phone className="w-5 h-5" /></button>
                  <button onClick={handleClearAiHistory} className="w-10 h-10 rounded-full bg-slate-800/50 flex items-center justify-center border border-white/5 hover:bg-red-500/20 hover:text-red-400 transition-all text-slate-400"><Icons.Trash className="w-5 h-5" /></button>
                </>
              )}
              <button onClick={() => setShowSettings(true)} className="w-10 h-10 rounded-full bg-slate-800/50 flex items-center justify-center border border-white/5 hover:bg-slate-700 transition-all text-slate-300"><Icons.Settings className="w-5 h-5" /></button>
              <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-cyan-400 p-0.5 shadow-[0_0_10px_rgba(34,211,238,0.3)]">
                <img src="https://picsum.photos/100/100?random=1" className="w-full h-full rounded-full object-cover" />
              </div>
            </div>
          </header>
        )}

        {/* Dashboard */}
        {view === View.DASHBOARD && (
          <div className="flex-1 overflow-y-auto px-6 py-8 space-y-6">
            <AdContainer type="banner" className="rounded-2xl" />
            <h2 className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.3em]">Encrypted Nodes</h2>
            {[...Array(6)].map((_, i) => (
              <div key={i} onClick={() => setView(View.CHAT_DETAIL)} className="flex items-center gap-4 p-5 glass-morphism rounded-[2rem] cursor-pointer hover:bg-white/5 active:scale-[0.98] transition-all border-white/5">
                <div className="relative">
                  <img src={`https://picsum.photos/100/100?random=${i+10}`} className="w-14 h-14 rounded-2xl object-cover shadow-2xl" />
                  <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-cyan-400 border-2 border-slate-900 rounded-full"></div>
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-center">
                    <h3 className="font-bold text-slate-100">Neural Node {i+1}</h3>
                    <span className="text-[10px] text-slate-500">NodeSync: OK</span>
                  </div>
                  <p className="text-sm text-slate-400 line-clamp-1">Buffer ready for 2TB stream. Initializing...</p>
                </div>
                <div className="bg-cyan-500/10 text-cyan-400 text-[10px] font-bold px-2 py-0.5 rounded-full">Secure</div>
              </div>
            ))}
          </div>
        )}

        {/* AI Chat View */}
        {view === View.AI_CHAT && (
          <div className="flex-1 flex flex-col overflow-hidden">
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {aiHistory.map(m => (
                <div key={m.id} className={`flex flex-col ${m.isMe ? 'items-end' : 'items-start'}`}>
                  <div className={`p-5 rounded-[2rem] max-w-[90%] shadow-2xl ${m.isMe ? 'bg-indigo-600 text-white rounded-tr-none' : 'glass-morphism border-white/5 rounded-tl-none text-slate-100'}`}>
                    <p className="text-sm leading-relaxed">{m.text}</p>
                  </div>
                </div>
              ))}
              {aiLoading && <div className="text-cyan-400 animate-pulse text-[10px] font-bold uppercase tracking-widest px-4">Neural processing...</div>}
              <div ref={messagesEndRef} />
            </div>
            <div className="p-6 border-t border-white/5 glass-morphism pb-24">
              <div className="flex items-center gap-3">
                <button onClick={() => setShowTranslator(!showTranslator)} className={`p-4 rounded-2xl transition-all border ${showTranslator ? 'bg-cyan-600 text-white border-cyan-400 shadow-[0_0_15px_rgba(34,211,238,0.3)]' : 'bg-slate-800 text-cyan-400 border-white/5'}`}><Icons.Globe className="w-6 h-6" /></button>
                <div className="flex-1 relative">
                  <input value={aiInputText} onChange={(e) => setAiInputText(e.target.value)} onKeyDown={(e) => e.key==='Enter' && handleAiSend(e.currentTarget.value)} placeholder={selectedLanguage ? `Translate to ${selectedLanguage}...` : "Neural uplink query..."} className={`w-full bg-slate-800 p-5 pr-24 rounded-3xl border border-white/5 focus:outline-none focus:ring-2 ${selectedLanguage ? 'focus:ring-indigo-500/40 ring-1 ring-indigo-500/20' : 'focus:ring-cyan-500/30'}`} />
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-2">
                    <button onClick={toggleVoiceInput} className={`p-2 rounded-xl transition-all ${isRecording ? 'text-red-500 bg-red-500/10 animate-pulse' : 'text-slate-500 hover:text-cyan-400'}`}><Icons.Microphone className="w-6 h-6" /></button>
                    <Icons.AI className={`w-6 h-6 ${selectedLanguage ? 'text-indigo-400' : 'text-cyan-400'}`} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Neural LIVE View */}
        {view === View.LIVE && (
          <div className="fixed inset-0 z-[60] dark-gradient flex flex-col p-8 pt-20">
            <div className="flex-1 flex flex-col items-center justify-center gap-12">
              <div className="relative">
                <div className={`w-48 h-48 rounded-full border-4 border-cyan-500/20 flex items-center justify-center ${liveStatus === 'linked' ? 'animate-pulse' : ''}`}>
                  <div className={`w-40 h-40 rounded-full bg-gradient-to-tr from-cyan-600 to-indigo-600 flex items-center justify-center shadow-[0_0_50px_rgba(34,211,238,0.3)] ${liveStatus === 'linked' ? 'scale-110' : 'scale-100'} transition-transform duration-500`}>
                    <Icons.Phone className="w-16 h-16 text-white" />
                  </div>
                </div>
                {liveStatus === 'linked' && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-64 h-64 rounded-full border border-cyan-400/30 animate-ping"></div>
                  </div>
                )}
              </div>
              <div className="text-center">
                <h2 className="text-3xl font-extrabold text-white tracking-tight uppercase">Neural Live</h2>
                <p className="text-cyan-400 text-xs font-bold uppercase tracking-[0.4em] mt-3 animate-pulse">{liveStatus === 'connecting' ? 'Establishing Direct-Link...' : 'Global Uplink: Active'}</p>
              </div>
              
              <div className="w-full max-w-sm flex-1 overflow-y-auto no-scrollbar space-y-4 pt-4">
                 {liveTranscriptions.map((t, idx) => (
                   <div key={idx} className="space-y-2 animate-in fade-in slide-in-from-bottom-2">
                     <p className="text-right text-xs text-indigo-300 font-bold opacity-70">YOU: {t.user}</p>
                     <p className="text-left text-sm text-cyan-100 font-medium">AI: {t.ai}</p>
                   </div>
                 ))}
                 <div ref={messagesEndRef} />
              </div>

              <button onClick={endLiveLink} className="w-20 h-20 bg-red-600 rounded-full flex items-center justify-center shadow-2xl active:scale-95 transition-all hover:bg-red-500 border-4 border-slate-900">
                <Icons.XCircle className="w-10 h-10 text-white" />
              </button>
            </div>
          </div>
        )}

        {/* Tab Bar */}
        {(view !== View.LOGIN && view !== View.LIVE) && (
          <nav className="fixed bottom-0 left-0 right-0 h-20 glass-morphism border-t border-white/5 flex items-center justify-around px-4 z-40">
            <button onClick={() => setView(View.DASHBOARD)} className={`flex flex-col items-center transition-all ${view === View.DASHBOARD || view === View.CHAT_DETAIL ? 'text-cyan-400 scale-110' : 'text-slate-500'}`}><Icons.Chat className="w-6 h-6" /><span className="text-[7px] mt-1 font-bold uppercase tracking-widest">Nodes</span></button>
            <button onClick={() => setView(View.AI_CHAT)} className={`flex flex-col items-center transition-all ${view === View.AI_CHAT ? 'text-cyan-400 scale-110' : 'text-slate-500'}`}><Icons.AI className="w-6 h-6" /><span className="text-[7px] mt-1 font-bold uppercase tracking-widest">Neural</span></button>
            <div className="relative -mt-10">
              <button onClick={() => setView(View.VIDEO_STUDIO)} className="w-14 h-14 bg-gradient-to-tr from-cyan-600 to-indigo-700 rounded-3xl shadow-[0_10px_30px_rgba(34,211,238,0.4)] flex items-center justify-center border-4 border-slate-950 rotate-45 transition-transform hover:rotate-90 active:scale-90"><Icons.PaperPlane className="w-7 h-7 text-white -rotate-45" /></button>
            </div>
            <button onClick={() => setView(View.CLOUD)} className={`flex flex-col items-center transition-all ${view === View.CLOUD ? 'text-cyan-400 scale-110' : 'text-slate-500'}`}><Icons.Cloud className="w-6 h-6" /><span className="text-[7px] mt-1 font-bold uppercase tracking-widest">Cloud</span></button>
            <button className="flex flex-col items-center text-slate-500"><Icons.Video className="w-6 h-6" /><span className="text-[7px] mt-1 font-bold uppercase tracking-widest">Studio</span></button>
          </nav>
        )}
      </main>

      {showSettings && (
        <div className="fixed inset-0 z-[100] flex items-end justify-center animate-in fade-in">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-md" onClick={() => setShowSettings(false)} />
          <div className="w-full max-w-sm glass-morphism rounded-t-[3rem] p-8 space-y-8 relative z-10 border-white/10 animate-in slide-in-from-bottom-24">
            <div className="text-center">
              <div className="w-20 h-20 rounded-[1.5rem] overflow-hidden mx-auto mb-4 border-2 border-cyan-400 p-1">
                <img src="https://picsum.photos/200/200?random=1" className="w-full h-full rounded-xl object-cover" />
              </div>
              <h2 className="text-xl font-bold">Neural Identity</h2>
              <p className="text-xs text-slate-500 mt-1">Status: Active Link (PRO)</p>
            </div>
            <div className="space-y-2">
              <button className="w-full p-5 bg-white/5 rounded-3xl text-left text-sm font-bold flex items-center justify-between border border-white/5">Manage Link Keys <span className="text-cyan-400">→</span></button>
              <button onClick={handleLogout} className="w-full p-5 bg-red-500/10 text-red-400 rounded-3xl text-left text-sm font-bold flex items-center justify-between border border-red-500/20">Terminate Session <Icons.Trash className="w-5 h-5" /></button>
            </div>
            <button onClick={() => setShowSettings(false)} className="w-full py-4 text-slate-500 text-xs font-bold uppercase">Return to Link</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
