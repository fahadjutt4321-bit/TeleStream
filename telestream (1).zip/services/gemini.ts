
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateAIResponse = async (prompt: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: "You are TeleStream Neural AI, a helpful, ultra-modern assistant integrated into the TeleStream app. You help with creative tasks, coding, translation, and media advice. TeleStream uses a VPN-free 'Direct-Link' system for 100% global availability. Maintain a high-tech, professional, and energetic tone.",
      }
    });
    return response.text || "Direct-Link communication failure. Please re-synchronize.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Neural uplink error. Check your Direct-Link connection.";
  }
};
