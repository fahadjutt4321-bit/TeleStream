
import React from 'react';

interface AdProps {
  type: 'banner' | 'interstitial' | 'native';
  className?: string;
}

const AdContainer: React.FC<AdProps> = ({ type, className }) => {
  return (
    <div className={`flex items-center justify-center bg-white/5 border border-dashed border-white/10 text-xs text-white/30 overflow-hidden ${className} ${type === 'banner' ? 'h-14 w-full' : 'h-32 w-full rounded-2xl'}`}>
      <div className="flex flex-col items-center gap-1">
        <span className="font-bold opacity-30 uppercase tracking-[0.3em] text-[8px]">Adsterra Network</span>
        <span>Secure Ad Link Established</span>
      </div>
    </div>
  );
};

export default AdContainer;
