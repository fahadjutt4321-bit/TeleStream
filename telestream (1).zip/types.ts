
export enum View {
  LOGIN = 'LOGIN',
  DASHBOARD = 'DASHBOARD',
  CHAT_DETAIL = 'CHAT_DETAIL',
  AI_CHAT = 'AI_CHAT',
  VIDEO_STUDIO = 'VIDEO_STUDIO',
  DESIGN_STUDIO = 'DESIGN_STUDIO',
  CLOUD = 'CLOUD',
  CHANNELS = 'CHANNELS',
  LIVE = 'LIVE'
}

export interface Message {
  id: string;
  sender: string;
  text: string;
  timestamp: string;
  isMe: boolean;
  type: 'text' | 'image' | 'video' | 'voice' | 'doc' | 'sticker';
  fileUrl?: string;
}

export interface Chat {
  id: string;
  name: string;
  lastMessage: string;
  time: string;
  avatar: string;
  unreadCount: number;
}
